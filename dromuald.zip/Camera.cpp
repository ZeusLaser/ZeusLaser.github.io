//
// sueda
// November, 2014
//

#include "Camera.h"
#include "MatrixStack.h"
#include <stdio.h>
#include <iostream>
#define GLM_FORCE_RADIANS
#include "glm/gtx/string_cast.hpp"
#include "glm/gtx/transform.hpp"

using namespace std;

Camera::Camera() :
	aspect(1.0f),
	fovy(30.0f/180.0f*M_PI),
	znear(0.1f),
	zfar(1000.0f),
	position(0.0f, 0.0f, -10.0f)
{
}

Camera::~Camera()
{
	
}

void Camera::setWindowSize(float w, float h)
{
	aspect = w/h;
}

void Camera::update(const bool *keys, const glm::vec2 &mouse)
{
	// How much has the mouse moved?
	float dx = mouse.x - mousePrev.x;
	float dy = mouse.y - mousePrev.y;

	// Update camera position and orientation here

	// Save last mouse
	mousePrev = mouse;
}

void Camera::applyProjectionMatrix(MatrixStack *P) const
{
	P->perspective(fovy, aspect, znear, zfar);
}

void Camera::applyViewMatrix(MatrixStack *MV, float forward, float horizontal, float pitch, float yaw) const
{
	// Create the translation and rotation matrices
	glm::mat4 Trans = glm::translate(position);
	Trans[3][0] = horizontal;
	Trans[3][1] = 1;
	Trans[3][2] = forward;
	
	pitch *= -1;

	glm::mat4 Rox;
	Rox[0][0] = cos(yaw/180 *M_PI);
	Rox[0][1] = 0.0;
	Rox[0][2] = sin(yaw/180 *M_PI);
	Rox[0][3] = 0.0;
	Rox[1][0] = 0.0;
	Rox[1][1] = 1.0;
	Rox[1][2] = 0.0;
	Rox[1][3] = 0.0;
	Rox[2][0] = -sin(yaw/180 *M_PI);
	Rox[2][1] = 0.0;
	Rox[2][2] = cos(yaw/180 *M_PI);
	Rox[2][3] = 0.0;
	Rox[3][0] = 0.0;
	Rox[3][1] = 0.0;
	Rox[3][2] = 0.0;
	Rox[3][3] = 1.0;
		
	glm::mat4 Roy;
	Roy[0][0] = 1.0;
	Roy[0][1] = 0.0;
	Roy[0][2] = 0.0;
	Roy[0][3] = 0.0;
	Roy[1][0] = 0.0;
	Roy[1][1] = cos(pitch/180 *M_PI);
	Roy[1][2] = -sin(pitch/180 *M_PI);
	Roy[1][3] = 0.0;
	Roy[2][0] = 0.0;
	Roy[2][1] = sin(pitch/180 *M_PI);
	Roy[2][2] = cos(pitch/180 *M_PI);
	Roy[2][3] = 0.0;
	Roy[3][0] = 0.0;
	Roy[3][1] = 0.0;
	Roy[3][2] = 0.0;
	Roy[3][3] = 1.0;

	//cout << Roy[1][1] << endl << Roy[1][2] << endl << Roy[2][1] << endl << Roy[2][2] << endl;

	// The matrix C is the product of these matrices
	glm::mat4 C = Roy * Rox * Trans; // Also apply rotations here
	
	glm::mat4 Rots = glm::inverse(Roy * Rox);
	glm::mat4 Tr = glm::inverse(Trans);
	
	//glm::mat4 C = Rox * Trans; // Also apply rotations here
		
	// The view matrix is the inverse
	//glm::mat4 V = Rots*Tr;
	glm::mat4 V = glm::inverse(C);
	// Add to the matrix stack
	//MV->rotate(pitch,glm::vec3(1.0f, 0.0f,0.0f));
	//MV->rotate(yaw, glm::vec3(0.0f, 1.0f, 0.0f));
	//V = Roy * V;
	MV->multMatrix(V);
}
