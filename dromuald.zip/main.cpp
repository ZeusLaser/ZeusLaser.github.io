#ifdef __APPLE__
#include <GLUT/glut.h>
#endif
#ifdef __unix__
#include <GL/glut.h>
#endif
#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <vector>
#include "GLSL.h"
#include "Camera.h"
#include "MatrixStack.h"
#include "Image.h"
#include "Shape.h"
#include "SolarSystemGlobals.h"

using namespace std;

Shape sun, pluto, saturn, mars, mercury, venus, earth, neptune, jupiter,
					uranus, moon;
Camera camera;
bool cull = false;
bool line = false;
glm::vec3 lightPosCam;

// GLSL program
GLuint pid;
// GLSL handles to various parameters in the shaders
GLint h_vertPosition;
GLint h_vertNormal;
GLint h_vertTexCoords;
GLint h_P;
GLint h_MV;
GLint h_T;
GLint h_texture0;
GLint h_texture1;
GLint h_texture2;
GLint sunText;
GLint h_lightPosCam;
float ticker = 0;
glm::vec2 mouse;
float fWard = 0, hor = 0;
float yaw = 0, pitch = 0;
bool keyDown[256] = {false};
int time0 = 0;

// OpenGL handle to texture data
GLuint texture0ID;
GLuint texture1ID;
GLuint texture2ID;
GLuint sunTexture;
GLuint uranusTexture;
GLuint venusTexture;
GLuint mercuryTexture;
GLuint marsTexture;
GLuint earthTexture;
GLuint saturnTexture;
GLuint jupiterTexture;
GLuint neptuneTexture;
GLuint plutoTexture;
GLuint moonTexture;

// Texture matrix
glm::mat3 T(1.0);

// This function just converts degrees to radians
float toRadians(float degrees) {
	return degrees / 180 * M_PI;
}

void loadScene()
{
	sun.load("sphere.obj");
	pluto.load("sphere.obj");
	venus.load("sphere.obj");
	mercury.load("sphere.obj");
	earth.load("sphere.obj");
	mars.load("sphere.obj");
	uranus.load("sphere.obj");
	mars.load("sphere.obj");
	jupiter.load("sphere.obj");
	saturn.load("sphere.obj");
	neptune.load("sphere.obj");
	moon.load("sphere.obj");
	lightPosCam = glm::vec3(0.0f + fWard, 0.0f + hor, -5.0f);
}

void initGL()
{
	//////////////////////////////////////////////////////
	// Initialize GL for the whole scene
	//////////////////////////////////////////////////////
	
	// Set background color
	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
	// Enable z-buffer test
	glEnable(GL_DEPTH_TEST);
	
	//////////////////////////////////////////////////////
	// Initialize the vertex buffers
	//////////////////////////////////////////////////////
	
	sun.init();
	mercury.init();
	venus.init();
	earth.init();
	mars.init();
	jupiter.init();
	saturn.init();
	uranus.init();
	neptune.init();
	pluto.init();
	moon.init();
	//////////////////////////////////////////////////////
	// Intialize the shaders
	//////////////////////////////////////////////////////
	
	// Create shader handles
	string vShaderName = "vert.glsl";
	string fShaderName = "frag.glsl";
	GLint rc;
	GLuint VS = glCreateShader(GL_VERTEX_SHADER);
	GLuint FS = glCreateShader(GL_FRAGMENT_SHADER);
	
	// Read shader sources
	const char *vshader = GLSL::textFileRead(vShaderName.c_str());
	const char *fshader = GLSL::textFileRead(fShaderName.c_str());
	glShaderSource(VS, 1, &vshader, NULL);
	glShaderSource(FS, 1, &fshader, NULL);
	
	// Compile vertex shader
	glCompileShader(VS);
	GLSL::printError();
	glGetShaderiv(VS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(VS);
	if(!rc) {
		printf("Error compiling vertex shader %s\n", vShaderName.c_str());
	}
	
	// Compile fragment shader
	glCompileShader(FS);
	GLSL::printError();
	glGetShaderiv(FS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(FS);
	if(!rc) {
		printf("Error compiling fragment shader %s\n", fShaderName.c_str());
	}
	
	// Create the program and link
	pid = glCreateProgram();
	glAttachShader(pid, VS);
	glAttachShader(pid, FS);
	glLinkProgram(pid);
	GLSL::printError();
	glGetProgramiv(pid, GL_LINK_STATUS, &rc);
	GLSL::printProgramInfoLog(pid);
	if(!rc) {
		printf("Error linking shaders %s and %s\n", vShaderName.c_str(), fShaderName.c_str());
	}
	h_vertPosition = GLSL::getAttribLocation(pid, "vertPosition");
	h_vertNormal = GLSL::getAttribLocation(pid, "vertNormal");
	h_vertTexCoords = GLSL::getAttribLocation(pid, "vertTexCoords");


	h_P = GLSL::getUniformLocation(pid, "P");
	h_MV = GLSL::getUniformLocation(pid, "MV");
	h_T = GLSL::getUniformLocation(pid, "T");
	h_texture0 = GLSL::getUniformLocation(pid, "texture0");
	h_texture1 = GLSL::getUniformLocation(pid, "texture1");
	h_texture2 = GLSL::getUniformLocation(pid, "texture2");
	h_lightPosCam = GLSL::getUniformLocation(pid, "lightPosCam");
	
	//////////////////////////////////////////////////////
	// Intialize textures
	//////////////////////////////////////////////////////
	
	// Load calpoly texture image
	Image *image0 = (Image *)malloc(sizeof(Image));
	if(image0 == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("earthKd.bmp", image0)) {
		printf("Error loading texture image\n");
	}

	// Set active texture to texture unit 0
	glActiveTexture(GL_TEXTURE0);
	// Generate a texture buffer object
	glGenTextures(1, &texture0ID);
	// Bind the current texture to be the newly generated texture object
	glBindTexture(GL_TEXTURE_2D, texture0ID);
	// Load the actual texture data
	// Base level is 0, number of channels is 3, and border is 0.
	glTexImage2D(GL_TEXTURE_2D, 0, 3, image0->sizeX, image0->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, image0->data);
	// Generate image pyramid
	glGenerateMipmap(GL_TEXTURE_2D);
	// Set texture wrap modes for the S and T directions
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// Set filtering mode for magnification and minimification
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	// Unbind
	glBindTexture(GL_TEXTURE_2D, 0);
	// Free image, since the data is now on the GPU
	free(image0);
	
	// Repeat
	Image *image1 = (Image *)malloc(sizeof(Image));
	if(image1 == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("earthKs.bmp", image1)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE1);
	glGenTextures(1, &texture1ID);
	glBindTexture(GL_TEXTURE_2D, texture1ID);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, image1->sizeX, image1->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, image1->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(image1);
	
	// Repeat
	Image *image2 = (Image *)malloc(sizeof(Image));
	if(image2 == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("earthClouds.bmp", image2)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &texture2ID);
	glBindTexture(GL_TEXTURE_2D, texture2ID);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, image2->sizeX, image2->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, image2->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(image2);
	
	// Repeat for the sun texture
	Image *sunI = (Image *)malloc(sizeof(Image));
	if(sunI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("sunmap.bmp", sunI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &sunTexture);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, sunI->sizeX, sunI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, sunI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(sunI);

	Image *moonI = (Image *)malloc(sizeof(Image));
	if(moonI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("moonmap.bmp", moonI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &moonTexture);
	glBindTexture(GL_TEXTURE_2D, moonTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, moonI->sizeX, moonI->sizeY,
			0, GL_RGB, GL_UNSIGNED_BYTE, moonI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(moonI);


	// Repeat for the pluto texture
	Image *plutoI = (Image *)malloc(sizeof(Image));
	if(plutoI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("plutomap.bmp", plutoI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &plutoTexture);
	glBindTexture(GL_TEXTURE_2D, plutoTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, plutoI->sizeX, plutoI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, plutoI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(plutoI);

	// Repeat for the neptune texture
	Image *neptuneI = (Image *)malloc(sizeof(Image));
	if(neptuneI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("neptunemap.bmp", neptuneI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &neptuneTexture);
	glBindTexture(GL_TEXTURE_2D, neptuneTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, neptuneI->sizeX, neptuneI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, neptuneI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(neptuneI);

	// Repeat for the jupiter texture
	Image *jupiterI = (Image *)malloc(sizeof(Image));
	if(jupiterI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("jupitermap.bmp", jupiterI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &jupiterTexture);
	glBindTexture(GL_TEXTURE_2D, jupiterTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, jupiterI->sizeX, jupiterI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, jupiterI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(jupiterI);

	// Repeat for the saturn texture
	Image *saturnI = (Image *)malloc(sizeof(Image));
	if(saturnI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("saturnmap.bmp", saturnI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &saturnTexture);
	glBindTexture(GL_TEXTURE_2D, saturnTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, saturnI->sizeX, saturnI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, saturnI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(saturnI);

	// Repeat for the uranus texture
	Image *uranusI = (Image *)malloc(sizeof(Image));
	if(uranusI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("uranusmap.bmp", uranusI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &uranusTexture);
	glBindTexture(GL_TEXTURE_2D, uranusTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, uranusI->sizeX, uranusI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, uranusI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(uranusI);

// Repeat for the venus texture
	Image *venusI = (Image *)malloc(sizeof(Image));
	if(venusI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("venusmap.bmp", venusI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &venusTexture);
	glBindTexture(GL_TEXTURE_2D, venusTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, venusI->sizeX, venusI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, venusI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(venusI);

// Repeat for the mercury texture
	Image *mercuryI = (Image *)malloc(sizeof(Image));
	if(mercuryI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("mercurymap.bmp", mercuryI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &mercuryTexture);
	glBindTexture(GL_TEXTURE_2D, mercuryTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, mercuryI->sizeX, mercuryI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, mercuryI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(mercuryI);

// Repeat for the mars texture
	Image *marsI = (Image *)malloc(sizeof(Image));
	if(marsI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("marsmap.bmp", marsI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &marsTexture);
	glBindTexture(GL_TEXTURE_2D, marsTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, marsI->sizeX, marsI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, marsI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(marsI);

// Repeat for the earth texture
	Image *earthI = (Image *)malloc(sizeof(Image));
	if(earthI == NULL) {
		printf("Error allocating space for image");
	}
	if(!ImageLoad("earthmap.bmp", earthI)) {
		printf("Error loading texture image\n");
	}
	glActiveTexture(GL_TEXTURE2);
	glGenTextures(1, &earthTexture);
	glBindTexture(GL_TEXTURE_2D,earthTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, earthI->sizeX, earthI->sizeY,
				 0, GL_RGB, GL_UNSIGNED_BYTE, earthI->data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	//glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glBindTexture(GL_TEXTURE_2D, 0);
	free(earthI);





	// Texture matrix for earth 
	T[0][0] = 1.0f;
	T[0][1] = 0.0f;
	T[0][2] = 0.0f;
	T[1][0] = 0.0f;
	T[1][1] = 1.0f;
	T[1][2] = 0.0f;
	T[2][0] = 0.0f;
	T[2][1] = 0.0f;
	T[2][2] = 1.0f;


	// Check GLSL
	GLSL::checkVersion();
}

void reshapeGL(int w, int h)
{
	// Set view size
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	// Set camera aspect ratio
	//camera.setAspect((float)w/h);
	camera.setWindowSize(w, h);
}

void drawGL()
{
	// Clear buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Enable backface culling
	if(cull) {
		glEnable(GL_CULL_FACE);
	} else {
		glDisable(GL_CULL_FACE);
	}
	if(line) {
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	} else {
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	
	// Create matrix stacks
	MatrixStack P, MV;
	// Apply camera transforms
	P.pushMatrix();
	camera.applyProjectionMatrix(&P);
	MV.pushMatrix();
	camera.applyViewMatrix(&MV, fWard, hor, pitch, yaw);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	// Bind the program
	glUseProgram(pid);
	glUniformMatrix4fv( h_P, 1, GL_FALSE, glm::value_ptr( P.topMatrix()));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	glUniform3fv(h_lightPosCam, 1, glm::value_ptr(lightPosCam));
	
	
	// Bind textures
	glActiveTexture(GL_TEXTURE0 + 0);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glUniform1i(h_texture0, 0);
	glActiveTexture(GL_TEXTURE0 + 1);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glUniform1i(h_texture1, 1);
	glActiveTexture(GL_TEXTURE0 + 2);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glUniform1i(h_texture2, 2);

	// Texture matrix
	// We're sending in GL_TRUE for the transpose argument, because we want
	// the translation to be the right-most column instead of the bottom row.
	glUniformMatrix3fv(h_T, 1, GL_TRUE, glm::value_ptr(T));
	MV.pushMatrix(); //Highest Level push
	MV.translate(glm::vec3(0.0f, 0.0f, -2.0f));

	// Draw solar system
	
	// Sun
	MV.pushMatrix();
	MV.scale(glm::vec3(0.2f, 0.2f, 0.2f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	sun.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();
	
	// Mercury
	glBindTexture(GL_TEXTURE_2D, 0);
	glBindTexture(GL_TEXTURE_2D, mercuryTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 44 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(0.3*cos(toRadians(267)), 0.3*sin(toRadians(267)), 0.0));
	MV.scale(glm::vec3(0.03f, 0.03f, 0.03f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	mercury.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();
	
	
	// Venus
	glBindTexture(GL_TEXTURE_2D, venusTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 110 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(0.43*cos(toRadians(285)), 0.43*sin(toRadians(285)), 0.0));
	MV.scale(glm::vec3(0.06f, 0.06f, 0.06f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	venus.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	// Earth
	glBindTexture(GL_TEXTURE_2D, earthTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 180 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(0.59*cos(toRadians(360)), 0.59*sin(toRadians(360)), 0.0));
	MV.scale(glm::vec3(0.06f, 0.06f, 0.06f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	earth.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();
	
	// Mars
	glBindTexture(GL_TEXTURE_2D, marsTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 90 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(0.71*cos(toRadians(78)), 0.71*sin(toRadians(78)), 0.0));
	MV.scale(glm::vec3(0.035f, 0.035f, 0.035f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	mars.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	// Jupiter
	//glBindTexture(GL_TEXTURE_2D, 0);
	glBindTexture(GL_TEXTURE_2D, jupiterTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 2100 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	//MV.rotate(ticker / 210 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(0.9*cos(toRadians(123)), 0.9*sin(toRadians(123)), 0.0));
	MV.scale(glm::vec3(0.1f, 0.1f, 0.1f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	jupiter.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	// Saturn
	//glBindTexture(GL_TEXTURE_2D, 0);
	glBindTexture(GL_TEXTURE_2D, saturnTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 5300 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(1.12*cos(toRadians(155)), 1.12*sin(toRadians(155)), 0.0));
	MV.scale(glm::vec3(0.095f, 0.095f, 0.095f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	saturn.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	//Uranus
	//glBindTexture(GL_TEXTURE_2D, 0);
	glBindTexture(GL_TEXTURE_2D, uranusTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 15100 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(1.3*cos(toRadians(194)), 1.3*sin(toRadians(194)), 0.0));
	MV.scale(glm::vec3(0.07f, 0.07f, 0.07f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	uranus.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	// Neptune
	glBindTexture(GL_TEXTURE_2D, neptuneTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 29700 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(1.49*cos(toRadians(219)), 1.49*sin(toRadians(219)), 0.0));
	MV.scale(glm::vec3(0.07f, 0.07f, 0.07f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	neptune.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();

	// Pluto
	glBindTexture(GL_TEXTURE_2D, 0);
	glBindTexture(GL_TEXTURE_2D, plutoTexture);
	glUniform1i(h_texture0, 0);
	MV.pushMatrix();	
	MV.rotate(ticker / 44600 * M_PI, glm::vec3(0.0f, 0.0f, 1.0f));
	MV.translate(glm::vec3(1.6*cos(toRadians(241)), 1.6*sin(toRadians(241)), 0.0));
	MV.scale(glm::vec3(0.02f, 0.02f, 0.02f));
	glUniformMatrix4fv(h_MV, 1, GL_FALSE, glm::value_ptr(MV.topMatrix()));
	pluto.draw(h_vertPosition, h_vertNormal, h_vertTexCoords);
	MV.popMatrix();








	MV.popMatrix();// Highest Level Pop
	
	
	// Unbind textures
	glActiveTexture(GL_TEXTURE0 + 0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glActiveTexture(GL_TEXTURE0 + 1);
	glBindTexture(GL_TEXTURE_2D, 0);
	glActiveTexture(GL_TEXTURE0 + 2);
	glBindTexture(GL_TEXTURE_2D, 0);


	// Unbind the program
	glUseProgram(0);

	// Pop stacks
	MV.popMatrix();
	P.popMatrix();

	// Double buffer
	glutSwapBuffers();
}


void keyboardGL(unsigned char key, int x, int y)
{
	keyDown[key] = true;
	switch(key) {
		case 27:
			// ESCAPE
			exit(0);
			break;
		case 'c':
			cull = !cull;
			break;
		case 'l':
			line = !line;
			break;
		case 'v':
			// align the planets!
			ticker = 0;
			break;
	}
	
	if( keyDown['w'] ) {
		fWard -= 0.1;
	}
	if( keyDown['s'] ) {
		fWard += 0.1;
	}
	if( keyDown['a'] ) {
		hor -= 0.1;
	}
	if( keyDown['d'] ) {
		hor += 0.1;
	}


	// Refresh screen
	glutPostRedisplay();
}

void keyboardUpGL(unsigned char key, int x, int y)
{
	   keyDown[key] = false;
}

void passiveMotionGL(int x, int y)
{
	mouse.x = x;
	mouse.y = y;
	if (x >= 200){
		yaw = x - 200;
		yaw = (yaw * 90) / 200; 
	}
	else{
		yaw = 200 -x;
		yaw = (yaw * -90) / 200;   
	}
	if (y >= 200) {
		pitch = y - 200;
		pitch = (pitch * 90) / 200; 
	}
	else {
		pitch = 200 - y;
		pitch = (pitch * -90) / 200;
	}
}




void idleGL()
{
	float t = glutGet(GLUT_ELAPSED_TIME);
	int time1 = glutGet(GLUT_ELAPSED_TIME);
	int dt = time1 - time0;
	ticker = t/1000;
	// Update every 60Hz
	if(dt > 1000.0/60.0) {
		time0 = time1;
		camera.update(keyDown, mouse);
		glutPostRedisplay();
	}


	glutPostRedisplay();
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitWindowSize(800, 800);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Zeus Laser");
	glutPassiveMotionFunc(passiveMotionGL);
	//glutMouseFunc(mouseGL);
	//glutMotionFunc(motionGL);
	glutKeyboardFunc(keyboardGL);
	glutKeyboardUpFunc(keyboardUpGL);
	glutReshapeFunc(reshapeGL);
	glutDisplayFunc(drawGL);
	glutIdleFunc(idleGL);
	loadScene();
	initGL();
	glutMainLoop();
	return 0;
}
